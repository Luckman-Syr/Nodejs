// const http = require("http");
// const fs = require("fs");

// const requestListener = (req, res) => {
//   const url = req.url;
//   res.writeHead(200, {
//     "Content-Type": "text/html",
//   });
 
//   switch(url){
//     case '/mhs':
//       renderPage(res,`src${url}.html`);
//       break;
//       case '/umur':
//         renderPage(res, `src${url}.html`);
//       break;
//     case '/':
//       renderPage(res, `src/index.html`);
//       break;
//     default:
//       res.write("<h1>404 Not Found</h1>");
//   }
// }

// function renderPage(res, src){
//   fs.readFile(src, (err, data) => {
//     if (err) {
//       console.log("error reading file:", err);
//     } else {
//       res.write(data);
//   }});
// }

// const server = http.createServer(requestListener);

// const port = 5000;
// const host = 'localhost';

// server.listen(port, host, () => {
//   console.log(`Server running at http://${host}:${port}/`);
// });

// const express = require('express')
// const app = express()
// const port = 3000

// app.get('/', (req, res) => {
//    res.send('Halaman Home')
// })

// app.get('/jurusan', (req, res) => {
//    res.send('Halaman Jurusan')
// })

// app.get('/mahasiswa', (req, res) => {
//    res.send('Halaman Mahasiswa')
// })

// app.use('/',(req,res)=>{
//    res.status(404);
//    res.send('<h1>404</h1>');
// })

// app.listen(port, () => {
//    console.log(`Example app listening at http://localhost:${port}`)
// })

// contoh 1
// const express = require('express')
// const app = express()
// const port = 3000

// app.get('/', function (req, res) {
//    res.sendFile('./index.html',{root:__dirname})
// })

// app.get('/jurusan', function (req, res) {
//    res.sendFile('./jurusan.html', { root: __dirname })

// })

// app.get('/mahasiswa', function (req, res) {
//    res.sendFile('./mahasiswa.html', { root: __dirname })
// })

// app.get('/Praktikum/:id/:kategori', function(req, res){
//   res.send(`Params = ${req.params.id}, ${req.params.kategori}`)
// })

// app.use('/',(req,res)=>{
//    res.status(404);
//    res.send('<h1>404</h1>');
// })

// app.listen(port, () => {
//    console.log(`Example app listening at http://localhost:${port}`)
// })


// Dengan engine 
const express = require('express')
const expressLayouts = require('express-ejs-layouts');
const app = express()
const port = 3000

app.set('view engine', 'ejs');
app.use(expressLayouts);

app.get('/', function (req, res) {
   const data ={
      title: "Halaman Home",
      layout: "layouts/main-layout"
   }
   res.render('index', data);
})

app.get('/jurusan', function (req, res) {
   const data ={
      title: "Halaman Home",
      layout: "layouts/main-layout"
   }
   res.render('jurusan',data);

})

app.get('/mahasiswa', function (req, res) {
   const data ={
      title: "Halaman Home",
      layout: "layouts/main-layout"
   }
   res.render('mahasiswa',data);
})

app.get('/Praktikum/:id/:kategori', function(req, res){
  res.send(`Params = ${req.params.id}, ${req.params.kategori}`)
})

app.use('/',(req,res)=>{
   res.status(404);
   res.send('<h1>404</h1>');
})

app.listen(port, () => {
   console.log(`Example app listening at http://localhost:${port}`)
})
