const validator = require("validator");
const readline = require("readline");
const {
  nanoid
} = require("nanoid");
const fs = require("fs");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

rl.question("email anda: ", (email) => {
  const id = "e" + nanoid();
  if (validator.isEmail(email)) {
    console.log("email valid");
    const newdata = {
      id,
      email,
    };
    fs.readFile("./datahistory.json", (err, data) => {
      if (err) {
        console.log("file read failed:", err);
      } else {
        const JSONdata = JSON.parse(data);
        JSONdata["email"].push(newdata);
        fs.writeFile("./datahistory.json", JSON.stringify(JSONdata), (err) => {
          if (err) {
            console.log("error writing file:", err);
            return;
          } else {
            console.log("file written successfully");
          }
        });
      }
    });
  } else {
    console.log("email invalid");
  }
  rl.close();
});

// const email = "Shazi@example.com"

// if(validator.isEmail(email)){
//     console.log("Email is valid");
// }else{
//     console.log("Email is invalid");
// }